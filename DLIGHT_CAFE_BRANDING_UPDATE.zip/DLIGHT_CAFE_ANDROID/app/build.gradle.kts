plugins {
    id("com.android.application")
}

android {
    namespace = "com.dlightcafe.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dlightcafe.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.core:core:1.15.0")
}
