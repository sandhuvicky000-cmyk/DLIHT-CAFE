const CAFE_WHATSAPP = "918699737678"; // Cafe order number, country code included
const DELIVERY_CHARGE = 30;

const img = {
 pizza:"https://images.unsplash.com/photo-1513104890138-7c749659a591?w=700",
 margherita:"https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=700",
 burger:"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=700",
 sandwich:"https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=700",
 fries:"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=700",
 wrap:"https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=700",
 drink:"https://images.unsplash.com/photo-1513558161293-c820ba4b7c73?w=700",
 garlic:"https://images.unsplash.com/photo-1619531040576-f94167406613?w=700",
 snack:"https://images.unsplash.com/photo-1601050690597-df0568f70950?w=700"
};
const products = [];
function addGroup(category, names, price, photo, desc="Freshly prepared at D’Light Cafe", sizes=null){
 names.forEach((name,i)=>products.push({id:products.length+1,name,category,price:price[i]??price[0],photo:photo[i%photo.length]||photo[0],desc,sizes}));
}
addGroup("Pizza",["Margherita Pizza"],[ {S:90,M:130,L:250} ],[img.margherita],"Tomato sauce, cheese and fresh basil",{S:90,M:130,L:250});
addGroup("Pizza",["King Pizza","Farm Pizza","Golden Pizza","Kurkure Pizza"],[{S:120,M:230,L:380}],[img.pizza],"Freshly baked classic pizza",{S:120,M:230,L:380});
addGroup("Pizza",["Green Veg Pizza","Supreme Pizza","Corn Special Pizza","Ultimate Pizza"],[{S:150,M:300,L:410}],[img.pizza],"Loaded with fresh vegetables",{S:150,M:300,L:410});
addGroup("Pizza",["Italian Pizza","Punjabi Tadka Pizza","Tandoori Pizza","Makhni Pizza"],[{S:170,M:350,L:470}],[img.pizza],"Feast range pizza",{S:170,M:350,L:470});
addGroup("Pizza",["Onion Pizza","Capsicum Pizza","Tomato Pizza","Corn Pizza","Cheese Mushroom Pizza","Tandoori Pizza (Simple Veg)","Paneer Makhni Pizza","Spicy Paneer Pizza","Mexican Pizza","D’Light Special Pizza"],[150,150,150,170,170,180,200,190,180,{M:230,L:450}],[img.pizza],"Simple veg pizza");
addGroup("Burger",["Allu Tikki Burger","Spicy Burger","Punjabi Burger","Tandoori Burger","Crunchy Burger","Corn Burger","Chips Burger","Cheese Slice Burger","Spicy’s Cheese Burger","Popular Burger","Maharaja Burger","Nuggets Burger","Spicy Paneer Burger","Special Burger"],[null,40,50,50,60,60,60,70,70,80,80,100,100,120],[img.burger],"Fresh burger served hot");
addGroup("Sandwich",["Cold Sandwich","Grill Sandwich","Corn Sandwich","Cheese + Onion + Corn","Chips Sandwich","Paneer Sandwich","Bread Pizza Sandwich","Mushroom Sandwich","Double Bread Sandwich","Special Sandwich"],[50,60,80,90,90,100,130,100,150,180],[img.sandwich],"Toasted and freshly made");
addGroup("Snacks",["French Fries","Masala French Fries","Potato Pops","Tandoori Nuggets","Cheese Pops","Hara Bhara Kabab","Cheese Corn Roll"],[80,100,100,150,180,180,230],[img.fries,img.snack],"Crispy cafe favourite");
addGroup("Wrap",["Veg Wrap","Crispy Wrap","Allu Tikka Wrap","Corn Crunch Wrap","Fries Wrap","Paneer Wrap"],[50,60,70,90,90,100],[img.wrap],"Wrapped fresh and delicious");
addGroup("Drinks",["Mint Mojito","Blue Mint","Strawberry Mojito","Green Apple"],[80,80,80,80],[img.drink],"Refreshing chilled drink");
addGroup("Tikki",["Veg Tikki"],[40],[img.snack],"Crispy potato tikki");
addGroup("Garlic Bread",["Garlic Bread"],[150],[img.garlic],"Garlic butter bread");
addGroup("Garlic Bread",["Stuffed Garlic Bread"],[150],[img.garlic],"Stuffed garlic bread – confirm variant price at cafe");

let cart=[], activeCategory="All", coupon=null, locationLink="";
const $=id=>document.getElementById(id);
const money=n=>"₹"+Math.round(n||0);
const categories=["All",...new Set(products.map(p=>p.category))];
function renderCategories(){
 $("categories").innerHTML=categories.map(c=>`<button class="cat-btn ${activeCategory===c?'active':''}" data-cat="${c}">${c==="All"?"✨ All items":c}</button>`).join("");
 $("categories").querySelectorAll("button").forEach(b=>b.onclick=()=>{activeCategory=b.dataset.cat;renderCategories();renderProducts();});
}
function productPrice(p,size){return typeof p.price==="object"?(p.price[size]||p.price.M):p.price}
function renderProducts(){
 const list=products.filter(p=>activeCategory==="All"||p.category===activeCategory);
 $("menuTitle").textContent=activeCategory==="All"?"Popular picks":activeCategory;
 $("menuCount").textContent=list.length+" items";
 $("products").innerHTML=list.map(p=>{
  const hasSize=typeof p.price==="object";
  const first=hasSize?(p.price.S?"S":"M"):"";
  const price=hasSize?productPrice(p,first):p.price;
  return `<article class="product"><img src="${p.photo}" alt="${p.name}" loading="lazy" onerror="this.src='https://placehold.co/600x400/252820/ffc629?text=D%27Light+Cafe'"><div class="product-body"><h3>${p.name}</h3><p>${p.desc}</p>${hasSize?`<select class="size-select" id="size-${p.id}">${Object.entries(p.price).map(([s,v])=>`<option value="${s}">${s} · ${money(v)}</option>`).join("")}</select>`:""}<div class="product-bottom"><span class="price" id="price-${p.id}">${money(price)}</span><button class="add-btn" data-add="${p.id}">+ Add</button></div></div></article>`;
 }).join("");
 $("products").querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>{const p=products.find(x=>x.id==b.dataset.add);const size=typeof p.price==="object"?$("size-"+p.id).value:"";addToCart(p,size);});
 $("products").querySelectorAll(".size-select").forEach(s=>s.onchange=()=>{const p=products.find(x=>x.id==s.id.split("-")[1]);$("price-"+p.id).textContent=money(productPrice(p,s.value));});
}
function addToCart(p,size){
 const key=p.id+"-"+size;const found=cart.find(x=>x.key===key);
 if(found)found.qty++;else cart.push({key,id:p.id,name:p.name,size,price:productPrice(p,size),qty:1});
 renderCart();toast(p.name+" added to cart");
}
function changeQty(key,delta){const item=cart.find(x=>x.key===key);if(!item)return;item.qty+=delta;if(item.qty<=0)cart=cart.filter(x=>x.key!==key);renderCart();}
function subtotal(){return cart.reduce((s,x)=>s+x.price*x.qty,0)}
function couponDiscount(sub){
 if(!coupon)return 0;
 if(coupon==="VICKY")return sub;
 const rules={WELCOME10:{min:199,type:"percent",value:10,cap:100},SAVE50:{min:399,type:"flat",value:50},PIZZA15:{min:299,type:"percent",value:15,cap:120},BURGER30:{min:199,type:"flat",value:30},WEEKEND20:{min:499,type:"percent",value:20,cap:150},BIG100:{min:799,type:"flat",value:100},SANDHU46:{min:300,type:"delivery",value:DELIVERY_CHARGE}};
 const r=rules[coupon];if(!r||sub<r.min)return 0;
 if(r.type==="delivery")return 0;
 return Math.min(r.type==="percent"?sub*r.value/100:r.value,r.cap||Infinity,sub);
}
function isFreeDelivery(sub){return (coupon==="SANDHU46"&&sub>=300)||coupon==="VICKY"}
function renderCart(){
 $("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
 $("cartItems").innerHTML=cart.length?cart.map(x=>`<div class="cart-line"><div><b>${x.name}${x.size?" · "+x.size:""}</b><small>${money(x.price)} each · ${money(x.price*x.qty)}</small></div><div class="qty"><button data-q="${x.key}" data-d="-1">−</button><b>${x.qty}</b><button data-q="${x.key}" data-d="1">+</button></div></div>`).join(""):'<p class="empty">Your cart is empty. Add something tasty!</p>';
 $("cartItems").querySelectorAll("[data-q]").forEach(b=>b.onclick=()=>changeQty(b.dataset.q,+b.dataset.d));
 const sub=subtotal(),disc=couponDiscount(sub),delivery=$("orderType").value==="Pickup"||isFreeDelivery(sub)?0:DELIVERY_CHARGE;
 $("subtotal").textContent=money(sub);$("discount").textContent="-"+money(disc);$("delivery").textContent=delivery?money(delivery):"FREE";const total=Math.max(0,sub-disc+delivery);$("total").textContent=money(total);if($("upiPaymentBox"))$("upiPaymentBox").hidden=$("paymentMethod").value!=="UPI"||coupon==="VICKY"||total===0;
}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2300)}
$("applyCoupon").onclick=()=>{
 const code=$("couponInput").value.trim().toUpperCase();
 const known=["WELCOME10","SAVE50","PIZZA15","BURGER30","WEEKEND20","BIG100","SANDHU46","VICKY"];
 if(!known.includes(code)){coupon=null;$("couponMessage").textContent="Invalid coupon code.";renderCart();return;}
 const mins={WELCOME10:199,SAVE50:399,PIZZA15:299,BURGER30:199,WEEKEND20:499,BIG100:799,SANDHU46:300};
 if(code!=="VICKY"&&subtotal()<(mins[code]||0)){$("couponMessage").textContent=`Add items worth ${money(mins[code]-subtotal())} more to use this code.`;return;}
 coupon=code;$("couponMessage").textContent=code==="VICKY"?"VICKY applied: your entire order is FREE!":code==="SANDHU46"?"Coupon applied: free delivery!":"Coupon applied successfully.";renderCart();
};
$("orderType").onchange=()=>{const pickup=$("orderType").value==="Pickup";$("address").required=!pickup;$("address").disabled=pickup;renderCart()};
$("attachLocation").onclick=()=>{
 if(!navigator.geolocation){toast("GPS is not available in this browser.");return;}
 $("locationStatus").textContent="Getting location…";
 navigator.geolocation.getCurrentPosition(pos=>{locationLink=`https://maps.google.com/?q=${pos.coords.latitude},${pos.coords.longitude}`;$("locationStatus").textContent="Location attached ✓";toast("Location attached");},()=>{$("locationStatus").textContent="Location permission denied";toast("Allow location access and try again");},{enableHighAccuracy:true,timeout:12000});
};
$("cartJump").onclick=()=>$("checkout").scrollIntoView({behavior:"smooth"});
function buildOrderMessage(){
 const sub=subtotal(),disc=couponDiscount(sub),pickup=$("orderType").value==="Pickup";
 const delivery=pickup||isFreeDelivery(sub)?0:DELIVERY_CHARGE,total=Math.max(0,sub-disc+delivery);
 const name=$("customerName").value.trim(),phone=$("customerPhone").value.trim();
 const address=$("address").value.trim(),note=$("specialNote").value.trim();
 const orderNo="DL"+Date.now().toString().slice(-7);
 const lines=[`*NEW D'LIGHT CAFE ORDER*`,`Order: ${orderNo}`,`Name: ${name}`,`Customer phone: ${phone}`,`Order type: ${pickup?"Self pickup":"Home delivery"}`,"","*ITEMS*",...cart.map(x=>`• ${x.name}${x.size?" ("+x.size+")":""} x${x.qty} = ${money(x.price*x.qty)}`),"",`Subtotal: ${money(sub)}`,`Coupon: ${coupon||"None"}`,`Discount: -${money(disc)}`,`Delivery: ${delivery?money(delivery):"FREE"}`,`*TOTAL: ${money(total)}*`,`Payment method: Cash on Delivery (COD)`,`Payment status: Pay cash on delivery / pickup`,`Address: ${pickup?"Self pickup":address||"Not supplied"}`,`Special note: ${note||"None"}`,`Location: ${locationLink||"Not attached"}`,"","Please confirm this order and delivery availability."];
 return encodeURIComponent(lines.join("\\n"));
}
$("orderForm").onsubmit=e=>{
 e.preventDefault();
 if(!cart.length){toast("Please add items to your cart.");return;}
 if(!e.currentTarget.reportValidity())return;
 const message=buildOrderMessage();
 window.location.href=`https://wa.me/${CAFE_WHATSAPP}?text=${message}`;
};
renderCategories();renderProducts();renderCart();
