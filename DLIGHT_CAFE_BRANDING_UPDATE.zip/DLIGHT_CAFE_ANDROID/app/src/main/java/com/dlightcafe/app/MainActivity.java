\
    package com.dlightcafe.app;

    import android.Manifest;
    import android.app.Activity;
    import android.content.ActivityNotFoundException;
    import android.content.Intent;
    import android.content.pm.PackageManager;
    import android.net.Uri;
    import android.os.Bundle;
    import android.os.Message;
    import android.webkit.GeolocationPermissions;
    import android.webkit.ValueCallback;
    import android.webkit.WebChromeClient;
    import android.webkit.WebResourceRequest;
    import android.webkit.WebSettings;
    import android.webkit.WebView;
    import android.webkit.WebViewClient;
    import android.widget.Toast;

    import androidx.webkit.WebViewAssetLoader;
import androidx.core.view.WindowCompat;

    public class MainActivity extends Activity {
        private static final int LOCATION_PERMISSION_REQUEST = 401;
        private WebView webView;
        private GeolocationPermissions.Callback pendingGeoCallback;
        private String pendingGeoOrigin;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
            getWindow().setStatusBarColor(android.graphics.Color.rgb(17, 18, 17));
            getWindow().setNavigationBarColor(android.graphics.Color.rgb(17, 18, 17));

            webView = new WebView(this);
            setContentView(webView);

            WebView.setWebContentsDebuggingEnabled(false);
            WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                    .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                    .build();

            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setMediaPlaybackRequiresUserGesture(false);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setGeolocationEnabled(true);
            settings.setLoadsImagesAutomatically(true);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            settings.setSupportMultipleWindows(true);
            settings.setJavaScriptCanOpenWindowsAutomatically(true);
            settings.setDefaultTextEncodingName("UTF-8");

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    return assetLoader.shouldInterceptRequest(request.getUrl());
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                    if (scheme.equals("https") && "appassets.androidplatform.net".equals(uri.getHost())) {
                        return false;
                    }
                    return openExternal(uri);
                }
            });

            webView.setWebChromeClient(new WebChromeClient() {
                @Override
                public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        callback.invoke(origin, true, false);
                    } else {
                        pendingGeoOrigin = origin;
                        pendingGeoCallback = callback;
                        requestPermissions(new String[] {
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION
                        }, LOCATION_PERMISSION_REQUEST);
                    }
                }

                @Override
                public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                    WebView popup = new WebView(MainActivity.this);
                    popup.setWebViewClient(new WebViewClient() {
                        @Override
                        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                            return openExternal(request.getUrl());
                        }
                        @Override
                        public boolean shouldOverrideUrlLoading(WebView v, String url) {
                            return openExternal(Uri.parse(url));
                        }
                    });
                    WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                    transport.setWebView(popup);
                    resultMsg.sendToTarget();
                    return true;
                }
            });

            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        }

        private boolean openExternal(Uri uri) {
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
            try {
                Intent intent;
                if (scheme.equals("http") || scheme.equals("https") || scheme.equals("upi")
                        || scheme.equals("tel") || scheme.equals("mailto")) {
                    intent = new Intent(Intent.ACTION_VIEW, uri);
                } else {
                    return true;
                }
                startActivity(intent);
            } catch (ActivityNotFoundException ex) {
                Toast.makeText(this, "No app found to open this link.", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(this, "Unable to open payment or order link.", Toast.LENGTH_LONG).show();
            }
            return true;
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            if (requestCode == LOCATION_PERMISSION_REQUEST && pendingGeoCallback != null) {
                boolean granted = false;
                for (int result : grantResults) {
                    if (result == PackageManager.PERMISSION_GRANTED) granted = true;
                }
                pendingGeoCallback.invoke(pendingGeoOrigin, granted, false);
                pendingGeoCallback = null;
                pendingGeoOrigin = null;
            }
        }

        @Override
        public void onBackPressed() {
            if (webView != null && webView.canGoBack()) webView.goBack();
            else super.onBackPressed();
        }

        @Override
        protected void onDestroy() {
            if (webView != null) {
                webView.loadUrl("about:blank");
                webView.destroy();
                webView = null;
            }
            super.onDestroy();
        }
    }
